using System.Data;
using Bai1_TiemTapHoa.Data;
using Bai1_TiemTapHoa.Models;
using ClosedXML.Excel;
using FastReport;
using FastReport.Export.PdfSimple;
using Microsoft.EntityFrameworkCore;

namespace Bai1_TiemTapHoa;

public class MainForm : Form
{
    private readonly TextBox txtTenHang = new();
    private readonly ComboBox cboLoaiHang = new();
    private readonly ComboBox cboDonVi = new();
    private readonly NumericUpDown nudGiaBan = new();
    private readonly NumericUpDown nudSoLuongTon = new();
    private readonly DateTimePicker dtpNgayNhap = new();
    private readonly CheckBox chkConKinhDoanh = new();
    private readonly DataGridView dgvHangHoa = new();
    private readonly TextBox txtTimKiem = new();
    private readonly ComboBox cboLocLoaiHang = new();
    private readonly CheckBox chkChiConKinhDoanh = new();
    private readonly Label lblTrangThai = new();
    private readonly System.Windows.Forms.Timer timerTimKiem = new() { Interval = 350 };
    private int? maHangDangChon;

    public MainForm()
    {
        Text = "Quản lý tiệm tạp hóa UTC2";
        Width = 1200;
        Height = 760;
        StartPosition = FormStartPosition.CenterScreen;
        BuildInterface();
        Load += MainForm_Load;
        timerTimKiem.Tick += async (_, _) =>
        {
            timerTimKiem.Stop();
            await LocHangHoaAsync();
        };
    }

    private void BuildInterface()
    {
        var info = new GroupBox { Text = "Thông tin hàng hóa", Dock = DockStyle.Top, Height = 170, Padding = new Padding(10) };
        Controls.Add(info);

        AddLabel(info, "Tên hàng", 15, 30);
        txtTenHang.SetBounds(100, 25, 240, 28); info.Controls.Add(txtTenHang);
        AddLabel(info, "Loại hàng", 365, 30);
        cboLoaiHang.SetBounds(445, 25, 190, 28); cboLoaiHang.DropDownStyle = ComboBoxStyle.DropDownList; info.Controls.Add(cboLoaiHang);
        AddLabel(info, "Đơn vị", 665, 30);
        cboDonVi.SetBounds(720, 25, 130, 28); cboDonVi.DropDownStyle = ComboBoxStyle.DropDownList; info.Controls.Add(cboDonVi);

        AddLabel(info, "Giá bán", 15, 75);
        nudGiaBan.SetBounds(100, 70, 150, 28); nudGiaBan.Maximum = 1000000000; nudGiaBan.Increment = 500; nudGiaBan.ThousandsSeparator = true; info.Controls.Add(nudGiaBan);
        AddLabel(info, "Số lượng tồn", 275, 75);
        nudSoLuongTon.SetBounds(365, 70, 120, 28); nudSoLuongTon.Maximum = 1000000; info.Controls.Add(nudSoLuongTon);
        AddLabel(info, "Ngày nhập", 515, 75);
        dtpNgayNhap.SetBounds(600, 70, 180, 28); dtpNgayNhap.Format = DateTimePickerFormat.Custom; dtpNgayNhap.CustomFormat = "dd/MM/yyyy"; info.Controls.Add(dtpNgayNhap);
        chkConKinhDoanh.Text = "Còn kinh doanh"; chkConKinhDoanh.SetBounds(805, 70, 150, 28); chkConKinhDoanh.Checked = true; info.Controls.Add(chkConKinhDoanh);

        var buttons = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 45, FlowDirection = FlowDirection.LeftToRight };
        info.Controls.Add(buttons);
        AddButton(buttons, "Thêm", async (_, _) => await ThemAsync());
        AddButton(buttons, "Sửa", async (_, _) => await SuaAsync());
        AddButton(buttons, "Xóa", async (_, _) => await XoaAsync());
        AddButton(buttons, "Làm mới", async (_, _) => await LamMoiAsync());

        var search = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 45, Padding = new Padding(5), WrapContents = false };
        Controls.Add(search);
        search.Controls.Add(new Label { Text = "Tìm tên:", AutoSize = true, Padding = new Padding(0, 8, 0, 0) });
        txtTimKiem.Width = 220; txtTimKiem.PlaceholderText = "Nhập tên hàng..."; search.Controls.Add(txtTimKiem);
        search.Controls.Add(new Label { Text = "Loại:", AutoSize = true, Padding = new Padding(8, 8, 0, 0) });
        cboLocLoaiHang.Width = 170; cboLocLoaiHang.DropDownStyle = ComboBoxStyle.DropDownList; search.Controls.Add(cboLocLoaiHang);
        chkChiConKinhDoanh.Text = "Chỉ hiện hàng còn kinh doanh"; chkChiConKinhDoanh.AutoSize = true; chkChiConKinhDoanh.Padding = new Padding(8, 7, 0, 0); search.Controls.Add(chkChiConKinhDoanh);

        dgvHangHoa.Dock = DockStyle.Fill;
        dgvHangHoa.ReadOnly = true;
        dgvHangHoa.AllowUserToAddRows = false;
        dgvHangHoa.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        dgvHangHoa.MultiSelect = false;
        dgvHangHoa.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        dgvHangHoa.CellClick += DgvHangHoa_CellClick;
        Controls.Add(dgvHangHoa);

        var bottom = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 48, Padding = new Padding(5) };
        Controls.Add(bottom);
        AddButton(bottom, "Xem bảng giá", async (_, _) => await XemBangGiaAsync());
        AddButton(bottom, "Xuất PDF", async (_, _) => await XuatPdfAsync());
        AddButton(bottom, "Xuất Excel (lưới)", (_, _) => XuatExcelLuoi());
        AddButton(bottom, "Xuất Excel tồn kho", async (_, _) => await XuatExcelTonKhoAsync());
        lblTrangThai.AutoSize = true; lblTrangThai.Padding = new Padding(15, 8, 0, 0); bottom.Controls.Add(lblTrangThai);

        txtTimKiem.TextChanged += (_, _) => { timerTimKiem.Stop(); timerTimKiem.Start(); };
        cboLocLoaiHang.SelectedIndexChanged += async (_, _) => await LocHangHoaAsync();
        chkChiConKinhDoanh.CheckedChanged += async (_, _) => await LocHangHoaAsync();
    }

    private static void AddLabel(Control parent, string text, int x, int y) =>
        parent.Controls.Add(new Label { Text = text, Left = x, Top = y + 5, AutoSize = true });

    private static void AddButton(Control parent, string text, EventHandler click)
    {
        var b = new Button { Text = text, Width = 125, Height = 32, Margin = new Padding(4) };
        b.Click += click;
        parent.Controls.Add(b);
    }

    private async void MainForm_Load(object? sender, EventArgs e)
    {
        cboLoaiHang.Items.AddRange(new object[] { "Đồ uống", "Thực phẩm khô", "Gia vị", "Đồ gia dụng" });
        cboDonVi.Items.AddRange(new object[] { "Chai", "Gói", "Hộp", "Túi" });
        cboLocLoaiHang.Items.Add("Tất cả");
        cboLocLoaiHang.Items.AddRange(new object[] { "Đồ uống", "Thực phẩm khô", "Gia vị", "Đồ gia dụng" });
        cboLocLoaiHang.SelectedIndex = 0;
        await TaiDanhSachHangHoaAsync();
    }

    private async Task TaiDanhSachHangHoaAsync()
    {
        try
        {
            using var db = new TiemTapHoaContext();
            var ds = await db.HangHoas.AsNoTracking().OrderBy(h => h.MaHang).ToListAsync();
            dgvHangHoa.DataSource = ds;
            DinhDangLuoi();
            lblTrangThai.Text = $"Tìm thấy {dgvHangHoa.Rows.Count} mặt hàng";
        }
        catch (Exception ex) { BaoLoi("tải hàng hóa", ex); }
    }

    private void DinhDangLuoi()
    {
        if (dgvHangHoa.Columns["GiaBan"] != null) dgvHangHoa.Columns["GiaBan"].DefaultCellStyle.Format = "N0";
        if (dgvHangHoa.Columns["NgayNhap"] != null) dgvHangHoa.Columns["NgayNhap"].DefaultCellStyle.Format = "dd/MM/yyyy";
        // DataGridView tự tạo CheckBoxColumn cho thuộc tính kiểu bool.
        if (dgvHangHoa.Columns["ConKinhDoanh"] != null)
            dgvHangHoa.Columns["ConKinhDoanh"].HeaderText = "Kinh doanh";
        if (dgvHangHoa.Columns["MaHang"] != null) dgvHangHoa.Columns["MaHang"].HeaderText = "Mã hàng";
        if (dgvHangHoa.Columns["TenHang"] != null) dgvHangHoa.Columns["TenHang"].HeaderText = "Tên hàng";
        if (dgvHangHoa.Columns["LoaiHang"] != null) dgvHangHoa.Columns["LoaiHang"].HeaderText = "Loại hàng";
        if (dgvHangHoa.Columns["DonVi"] != null) dgvHangHoa.Columns["DonVi"].HeaderText = "Đơn vị";
        if (dgvHangHoa.Columns["GiaBan"] != null) dgvHangHoa.Columns["GiaBan"].HeaderText = "Giá bán";
        if (dgvHangHoa.Columns["SoLuongTon"] != null) dgvHangHoa.Columns["SoLuongTon"].HeaderText = "Số lượng tồn";
        if (dgvHangHoa.Columns["NgayNhap"] != null) dgvHangHoa.Columns["NgayNhap"].HeaderText = "Ngày nhập";
    }

    private async Task LocHangHoaAsync()
    {
        try
        {
            using var db = new TiemTapHoaContext();
            IQueryable<HangHoa> q = db.HangHoas.AsNoTracking();
            string ten = txtTimKiem.Text.Trim();
            if (ten.Length > 0) q = q.Where(h => h.TenHang.Contains(ten));
            if (cboLocLoaiHang.SelectedIndex > 0) q = q.Where(h => h.LoaiHang == cboLocLoaiHang.Text);
            if (chkChiConKinhDoanh.Checked) q = q.Where(h => h.ConKinhDoanh);
            dgvHangHoa.DataSource = await q.OrderBy(h => h.MaHang).ToListAsync();
            DinhDangLuoi();
            lblTrangThai.Text = $"Tìm thấy {dgvHangHoa.Rows.Count} mặt hàng";
        }
        catch (Exception ex) { BaoLoi("tìm kiếm", ex); }
    }

    private void DgvHangHoa_CellClick(object? sender, DataGridViewCellEventArgs e)
    {
        if (e.RowIndex < 0) return;
        var r = dgvHangHoa.Rows[e.RowIndex];
        maHangDangChon = Convert.ToInt32(r.Cells["MaHang"].Value);
        txtTenHang.Text = Convert.ToString(r.Cells["TenHang"].Value) ?? "";
        cboLoaiHang.Text = Convert.ToString(r.Cells["LoaiHang"].Value) ?? "";
        cboDonVi.Text = Convert.ToString(r.Cells["DonVi"].Value) ?? "";
        nudGiaBan.Value = Math.Clamp(Convert.ToDecimal(r.Cells["GiaBan"].Value), nudGiaBan.Minimum, nudGiaBan.Maximum);
        nudSoLuongTon.Value = Math.Clamp(Convert.ToDecimal(r.Cells["SoLuongTon"].Value), nudSoLuongTon.Minimum, nudSoLuongTon.Maximum);
        dtpNgayNhap.Value = Convert.ToDateTime(r.Cells["NgayNhap"].Value);
        chkConKinhDoanh.Checked = Convert.ToBoolean(r.Cells["ConKinhDoanh"].Value);
    }

    private bool KiemTraNhap()
    {
        if (string.IsNullOrWhiteSpace(txtTenHang.Text))
        {
            MessageBox.Show("Tên hàng không được để trống."); txtTenHang.Focus(); return false;
        }
        if (nudGiaBan.Value <= 0) { MessageBox.Show("Giá bán phải lớn hơn 0."); return false; }
        return true;
    }

    private HangHoa TaoHangHoa() => new()
    {
        TenHang = txtTenHang.Text.Trim(),
        LoaiHang = string.IsNullOrWhiteSpace(cboLoaiHang.Text) ? null : cboLoaiHang.Text,
        DonVi = string.IsNullOrWhiteSpace(cboDonVi.Text) ? null : cboDonVi.Text,
        GiaBan = nudGiaBan.Value,
        SoLuongTon = (int)nudSoLuongTon.Value,
        NgayNhap = dtpNgayNhap.Value,
        ConKinhDoanh = chkConKinhDoanh.Checked
    };

    private async Task ThemAsync()
    {
        if (!KiemTraNhap()) return;
        try
        {
            using var db = new TiemTapHoaContext();
            db.HangHoas.Add(TaoHangHoa());
            await db.SaveChangesAsync();
            await LocHangHoaAsync();
            MessageBox.Show("Thêm hàng hóa thành công.");
        }
        catch (Exception ex) { BaoLoi("thêm hàng", ex); }
    }

    private async Task SuaAsync()
    {
        if (maHangDangChon == null) { MessageBox.Show("Chọn mặt hàng cần sửa."); return; }
        if (!KiemTraNhap()) return;
        try
        {
            using var db = new TiemTapHoaContext();
            var h = await db.HangHoas.FindAsync(maHangDangChon.Value);
            if (h == null) { MessageBox.Show("Không tìm thấy mặt hàng."); return; }
            var input = TaoHangHoa();
            h.TenHang = input.TenHang; h.LoaiHang = input.LoaiHang; h.DonVi = input.DonVi;
            h.GiaBan = input.GiaBan; h.SoLuongTon = input.SoLuongTon;
            h.NgayNhap = input.NgayNhap; h.ConKinhDoanh = input.ConKinhDoanh;
            await db.SaveChangesAsync();
            await LocHangHoaAsync();
            MessageBox.Show("Sửa hàng hóa thành công.");
        }
        catch (Exception ex) { BaoLoi("sửa hàng", ex); }
    }

    private async Task XoaAsync()
    {
        if (maHangDangChon == null) { MessageBox.Show("Chọn mặt hàng cần xóa."); return; }
        if (MessageBox.Show("Bạn có chắc muốn xóa mặt hàng này?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
        try
        {
            using var db = new TiemTapHoaContext();
            var h = await db.HangHoas.FindAsync(maHangDangChon.Value);
            if (h != null) { db.HangHoas.Remove(h); await db.SaveChangesAsync(); }
            maHangDangChon = null;
            await LocHangHoaAsync();
            MessageBox.Show("Xóa hàng hóa thành công.");
        }
        catch (Exception ex) { BaoLoi("xóa hàng", ex); }
    }

    private async Task LamMoiAsync()
    {
        maHangDangChon = null; txtTenHang.Clear(); cboLoaiHang.SelectedIndex = -1; cboDonVi.SelectedIndex = -1;
        nudGiaBan.Value = 0; nudSoLuongTon.Value = 0; dtpNgayNhap.Value = DateTime.Now; chkConKinhDoanh.Checked = true;
        txtTimKiem.Clear(); cboLocLoaiHang.SelectedIndex = 0; chkChiConKinhDoanh.Checked = false;
        await TaiDanhSachHangHoaAsync();
    }

    private async Task<DataTable> LayDataTableBaoCaoAsync()
    {
        using var db = new TiemTapHoaContext();
        var data = await db.HangHoas.AsNoTracking().Where(h => h.ConKinhDoanh)
            .OrderBy(h => h.MaHang).Select(h => new { h.TenHang, h.DonVi, h.GiaBan }).ToListAsync();
        var table = new DataTable("HangHoa");
        table.Columns.Add("TenHang", typeof(string));
        table.Columns.Add("DonVi", typeof(string));
        table.Columns.Add("GiaBan", typeof(decimal));
        foreach (var h in data) table.Rows.Add(h.TenHang, h.DonVi, h.GiaBan);
        return table;
    }

    private async Task<Report> TaoReportAsync()
    {
        var table = await LayDataTableBaoCaoAsync();
        var report = new Report();
        string path = Path.Combine(AppContext.BaseDirectory, "Reports", "BangGia.frx");
        report.Load(path);
        report.RegisterData(table, "HangHoa");
        var source = report.GetDataSource("HangHoa");
        if (source == null) { report.Dispose(); throw new InvalidOperationException("Mẫu report chưa có nguồn dữ liệu HangHoa."); }
        source.Enabled = true;
        report.SetParameterValue("NgayIn", DateTime.Now.ToString("dd/MM/yyyy HH:mm"));
        report.Prepare();
        return report;
    }

    private async Task XemBangGiaAsync()
    {
        try { using var report = await TaoReportAsync(); report.ShowPrepared(); }
        catch (Exception ex) { BaoLoi("xem bảng giá", ex); }
    }

    private async Task XuatPdfAsync()
    {
        using var dialog = new SaveFileDialog { Filter = "PDF (*.pdf)|*.pdf", FileName = "BangGia.pdf" };
        if (dialog.ShowDialog() != DialogResult.OK) return;
        try
        {
            using var report = await TaoReportAsync();
            using var export = new PDFSimpleExport();
            report.Export(export, dialog.FileName);
            if (MessageBox.Show("Xuất PDF thành công. Bạn có muốn mở file không?", "Hoàn tất", MessageBoxButtons.YesNo) == DialogResult.Yes)
                System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(dialog.FileName) { UseShellExecute = true });
        }
        catch (Exception ex) { BaoLoi("xuất PDF", ex); }
    }

    private void XuatExcelLuoi()
    {
        using var dialog = new SaveFileDialog { Filter = "Excel (*.xlsx)|*.xlsx", FileName = "DanhSachHangHoa.xlsx" };
        if (dialog.ShowDialog() != DialogResult.OK) return;
        try
        {
            using var wb = new XLWorkbook();
            var ws = wb.Worksheets.Add("HangHoa");
            var visibleColumns = dgvHangHoa.Columns.Cast<DataGridViewColumn>().Where(c => c.Visible).ToList();
            for (int c = 0; c < visibleColumns.Count; c++)
                ws.Cell(1, c + 1).Value = visibleColumns[c].HeaderText;
            int excelRow = 2;
            foreach (DataGridViewRow row in dgvHangHoa.Rows)
            {
                if (row.IsNewRow) continue;
                for (int c = 0; c < visibleColumns.Count; c++)
                {
                    var val = row.Cells[visibleColumns[c].Index].Value;
                    var cell = ws.Cell(excelRow, c + 1);
                    if (val == null || val == DBNull.Value) continue;
                    if (val is int i) cell.Value = i;
                    else if (val is decimal d) cell.Value = d;
                    else if (val is DateTime dt) cell.Value = dt;
                    else if (val is bool b) cell.Value = b;
                    else if (val is long l) cell.Value = l;
                    else cell.Value = val.ToString();
                }
                excelRow++;
            }
            ws.Row(1).Style.Font.Bold = true;
            ws.Columns().AdjustToContents();
            wb.SaveAs(dialog.FileName);
            MessageBox.Show("Xuất Excel từ lưới thành công.");
        }
        catch (IOException) { MessageBox.Show("Không lưu được file. Hãy đóng file Excel đang mở rồi thử lại."); }
        catch (Exception ex) { BaoLoi("xuất Excel từ lưới", ex); }
    }

    private async Task XuatExcelTonKhoAsync()
    {
        using var dialog = new SaveFileDialog { Filter = "Excel (*.xlsx)|*.xlsx", FileName = "BaoCaoTonKho.xlsx" };
        if (dialog.ShowDialog() != DialogResult.OK) return;
        try
        {
            using var db = new TiemTapHoaContext();
            var ds = await db.HangHoas.AsNoTracking().Where(h => h.ConKinhDoanh).OrderBy(h => h.MaHang).ToListAsync();
            using var wb = new XLWorkbook();
            var ws = wb.Worksheets.Add("TonKho");
            string[] headers = { "Mã hàng", "Tên hàng", "Loại hàng", "Đơn vị", "Giá bán", "Số lượng tồn", "Giá trị tồn" };
            for (int c = 0; c < headers.Length; c++) ws.Cell(1, c + 1).Value = headers[c];
            for (int i = 0; i < ds.Count; i++)
            {
                int r = i + 2; var h = ds[i];
                ws.Cell(r, 1).Value = h.MaHang; ws.Cell(r, 2).Value = h.TenHang;
                ws.Cell(r, 3).Value = h.LoaiHang ?? ""; ws.Cell(r, 4).Value = h.DonVi ?? "";
                ws.Cell(r, 5).Value = h.GiaBan; ws.Cell(r, 6).Value = h.SoLuongTon;
                ws.Cell(r, 7).FormulaA1 = $"=E{r}*F{r}";
            }
            int totalRow = ds.Count + 2;
            ws.Cell(totalRow, 6).Value = "Tổng";
            ws.Cell(totalRow, 7).FormulaA1 = $"=SUM(G2:G{totalRow - 1})";
            ws.Row(1).Style.Font.Bold = true; ws.Row(totalRow).Style.Font.Bold = true;
            ws.Range(1, 1, totalRow, 7).SetAutoFilter();
            ws.SheetView.FreezeRows(1);
            ws.Columns().AdjustToContents();
            wb.SaveAs(dialog.FileName);
            MessageBox.Show("Xuất Excel tồn kho thành công.");
        }
        catch (IOException) { MessageBox.Show("Hãy đóng file Excel đang mở rồi thử lại."); }
        catch (Exception ex) { BaoLoi("xuất Excel tồn kho", ex); }
    }

    private static void BaoLoi(string thaoTac, Exception ex) =>
        MessageBox.Show($"Lỗi {thaoTac}: {ex.Message}", "Thông báo lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
}
