# Bài 1 - Tiệm tạp hóa UTC2

## Nội dung
- WinForms .NET 10
- SQL Server LocalDB + EF Core
- Thêm / sửa / xóa / tìm kiếm có lọc loại hàng và trạng thái kinh doanh
- Xuất Excel từ các dòng đang hiển thị và Excel tồn kho có công thức
- FastReport xem trước và xuất PDF từ mẫu `Reports/BangGia.frx`

## Cách chạy
1. Cài Visual Studio 2022 có workload **.NET desktop development** và .NET 10 SDK.
2. Mở SQL Server Management Studio, kết nối `(localdb)\\MSSQLLocalDB`.
3. Mở và chạy toàn bộ `Scripts/TiemTapHoa.sql`.
4. Mở `Bai1_TiemTapHoa.csproj` trong Visual Studio.
5. Restore NuGet packages rồi nhấn F5.

Nếu SQL Server của máy dùng instance khác, sửa connection string trong `Data/TiemTapHoaContext.cs`.

## Lưu ý về FastReport
Dự án tham chiếu FastReport Open Source. Nếu NuGet báo không tìm thấy hoặc không tương thích phiên bản, mở Manage NuGet Packages và cài các gói FastReport tương thích với .NET đang cài. File `.frx` được đặt trong thư mục `Reports`.

## Yêu cầu nộp bài
Nộp cả project, `Scripts/TiemTapHoa.sql`, `Reports/BangGia.frx` và ảnh chụp kết quả chạy chương trình.
