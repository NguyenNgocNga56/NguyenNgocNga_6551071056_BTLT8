namespace Bai1_TiemTapHoa.Models;

// Entity model tương ứng bảng HangHoa trong SQL Server.
public class HangHoa
{
    public int MaHang { get; set; }
    public string TenHang { get; set; } = "";
    public string? LoaiHang { get; set; }
    public string? DonVi { get; set; }
    public decimal GiaBan { get; set; }
    public int SoLuongTon { get; set; }
    public DateTime NgayNhap { get; set; }
    public bool ConKinhDoanh { get; set; }
}
