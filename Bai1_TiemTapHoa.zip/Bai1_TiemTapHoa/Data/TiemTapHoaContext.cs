using Bai1_TiemTapHoa.Models;
using Microsoft.EntityFrameworkCore;

namespace Bai1_TiemTapHoa.Data;

public class TiemTapHoaContext : DbContext
{
    public DbSet<HangHoa> HangHoas => Set<HangHoa>();

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        if (!optionsBuilder.IsConfigured)
            optionsBuilder.UseSqlServer(
                @"Server=(localdb)\MSSQLLocalDB;Database=TiemTapHoa;Trusted_Connection=True;TrustServerCertificate=True");
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<HangHoa>(entity =>
        {
            entity.ToTable("HangHoa");
            entity.HasKey(e => e.MaHang);
            entity.Property(e => e.MaHang).ValueGeneratedOnAdd();
            entity.Property(e => e.TenHang).HasMaxLength(100).IsRequired();
            entity.Property(e => e.LoaiHang).HasMaxLength(50);
            entity.Property(e => e.DonVi).HasMaxLength(20);
            entity.Property(e => e.GiaBan).HasColumnType("decimal(18,0)");
            entity.Property(e => e.NgayNhap).HasColumnType("datetime");
        });
    }
}
